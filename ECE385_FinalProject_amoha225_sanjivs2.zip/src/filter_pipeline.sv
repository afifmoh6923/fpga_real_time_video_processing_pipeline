
// This module:
//   1. Expands the 16-bit RGB565 frame-buffer pixel to 24-bit RGB888
//   2. Optionally substitutes a colour-bar test pattern (SW[15])
//   3. Chains all filter stages in order:
//        brightness_contrast ? channel_isolate ? grayscale ?
//        box_blur ? silhoutte ? edge_detect
//   4. Generates pixel_advance and row_advance control signals for the
//      neighbourhood filters (line buffers).

module filter_pipeline (
    input  logic        pixel_clk,
    input  logic        reset,

    input  logic [15:0] SW,             // synchronised switch 

    // VGA scan position
    input  logic [9:0]  drawX,
    input  logic [9:0]  drawY,
    input  logic        active_nblank,  // HIGH = active video

    // Frame-buffer read data 
    input  logic [15:0] fb_data,

    // Filtered output
    output logic [23:0] filtered_rgb,
    output logic        pvalid_out
);

    logic [7:0] R8, G8, B8, G8_attenuated;
    
    assign R8 = {fb_data[15:11], fb_data[15:13]};
    assign G8 = {fb_data[10:5],  fb_data[10:9]};
    assign B8 = {fb_data[4:0],   fb_data[4:2]};
    
    // Subtract 12.5% of the green intensity to suppress the noise floor
    assign G8_attenuated = G8 - (G8 >> 2); 
    
    logic [23:0] rgb888;
    
    assign rgb888 = {R8, G8_attenuated, B8};

    logic [23:0] rgb888_clean;
    always_comb begin
        rgb888_clean = rgb888; // Default: pass the pixel through unchanged

        if (rgb888[15:8] > (rgb888[23:16] + 8'd20) && rgb888[15:8] > (rgb888[7:0] + 8'd20)) begin
            // Force Green to match the Red level
            rgb888_clean[15:8] = rgb888[23:16];
        end
        // BLUE SHADOW HEALER: Fixes blue static in your hair/shadows
        else if (rgb888[7:0] > (rgb888[23:16] + 8'd20) && rgb888[23:16] < 8'd100) begin
            rgb888_clean[7:0] = rgb888[23:16];
        end
        // Thermal Noise Gate: Crush background static to pure black
        else if (rgb888[23:16] < 8'd25 && rgb888[15:8] < 8'd25 && rgb888[7:0] < 8'd35) begin
            rgb888_clean = 24'h000000;
        end
    end

 // Test pattern generation
    logic [23:0] test_pattern;
    always_comb begin
        case ((drawX-10'd60)/40)
            3'd0: test_pattern = 24'hFFFFFF;
            3'd1: test_pattern = 24'hFFFF00;
            3'd2: test_pattern = 24'h00FFFF;
            3'd3: test_pattern = 24'h00FF00;
            3'd4: test_pattern = 24'hFF00FF;
            3'd5: test_pattern = 24'hFF0000;
            3'd6: test_pattern = 24'h0000FF;
            3'd7: test_pattern = 24'h000000;
            default: test_pattern = 24'h000000;
        endcase
    end

    
    // Define the centered 320x240 boundary
    logic in_window;
    assign in_window = (drawX >= 10'd160) && (drawX < 10'd480) && 
                       (drawY >= 10'd120) && (drawY < 10'd360);

    // Tell the filters to advance every single pixel, but ONLY inside the window
    logic pixel_advance;
    logic row_advance;

    assign pixel_advance = active_nblank && in_window;
    
    // Pulse once at the exact start of the active camera row (Column 160)
    assign row_advance   = active_nblank && in_window && (drawX == 10'd160);

    // ... (Keep STEP 2 and the test_pattern case statement exactly the same) ...

    // Update STEP 3: Draw black if we are outside the 320x240 window
    logic [23:0] source_rgb;
    assign source_rgb = SW[15] ? (active_nblank ? test_pattern : 24'h000000) : 
                                 (in_window ? rgb888_clean : 24'h000000);
    // pixel_valid: active video indicator
    logic pixel_valid;
    assign pixel_valid = active_nblank;

    // Filter Chain

    // Stage 1: Brightness / Contrast 
    logic [23:0] s1_out; logic s1_valid;
    brightness_contrast s1 (
        .clk          (pixel_clk),  .reset        (reset),
        .en_brightness(SW[3]),      .en_contrast  (SW[4]),
        .pixel_valid  (pixel_valid),.rgb_in       (source_rgb),
        .rgb_out      (s1_out),     .pvalid_out   (s1_valid)
    );

    // Stage 2: Channel Isolation 
    logic [23:0] s2_out; logic s2_valid;
    channel_isolate s2 (
        .clk        (pixel_clk),  .reset      (reset),
        .en_R       (SW[5]),      .en_G       (SW[6]),     .en_B(SW[7]),
        .pixel_valid(s1_valid),   .rgb_in     (s1_out),
        .rgb_out    (s2_out),     .pvalid_out (s2_valid)
    );

    // Stage 3: Grayscale 
    logic [23:0] s3_out; logic s3_valid;
    grayscale s3 (
        .clk        (pixel_clk),  .reset      (reset),
        .enable     (SW[11]),
        .pixel_valid(s2_valid),   .rgb_in     (s2_out),
        .rgb_out    (s3_out),     .pvalid_out (s3_valid)
    );

    // Stage 4: Box Blur 
    logic [23:0] s4_out; logic s4_valid;
    box_blur s4 (
        .clk          (pixel_clk), .reset        (reset),
        .enable       (SW[2]),
        .pixel_advance(pixel_advance), .row_advance(row_advance),
        .pixel_valid  (s3_valid),  .rgb_in       (s3_out),
        .rgb_out      (s4_out),    .pvalid_out   (s4_valid)
    );
    logic [8:0] pa_pipe, ra_pipe; // Pipeline for pixel and row advance signals
    always_ff @(posedge pixel_clk) begin
        if (reset) begin
            pa_pipe <= '0;
            ra_pipe <= '0;
        end else begin
            pa_pipe <= {pa_pipe[7:0], pixel_advance};
            ra_pipe <= {ra_pipe[7:0], row_advance};
        end
    end
    // Stage 5: Silhoutte
    logic [23:0] s5_out; logic s5_valid;
    silhoutte s5 (
        .clk          (pixel_clk), .reset        (reset),
        .enable       (SW[8]),
        .pixel_advance(pa_pipe[4]), .row_advance(ra_pipe[4]),
        .pixel_valid  (s4_valid),  .rgb_in       (s4_out),
        .rgb_out      (s5_out),    .pvalid_out   (s5_valid)
    );

    // ?? Stage 6: Edge Detection ???????????????????????????????????????????????
    logic [23:0] s6_out; logic s6_valid;
    edge_detect s6 (
        .clk          (pixel_clk), .reset        (reset),
        .enable       (SW[1]),
        .pixel_advance(pa_pipe[6]), .row_advance(ra_pipe[6]),
        .pixel_valid  (s5_valid),  .rgb_in       (s5_out),
        .rgb_out      (s6_out),    .pvalid_out   (s6_valid)
    );
    logic [23:0] s7_out; logic s7_valid;
    emboss s7 (
        .clk          (pixel_clk), .reset        (reset),
        .enable       (SW[9]),
        .pixel_advance(pa_pipe[8]), .row_advance(ra_pipe[8]),
        .pixel_valid  (s6_valid),  .rgb_in       (s6_out),
        .rgb_out      (s7_out),    .pvalid_out   (s7_valid)
    );
    logic [23:0] s8_out; logic s8_valid;
    invert s8 (
        .clk        (pixel_clk), .reset      (reset),
        .enable     (SW[12]),
        .pixel_valid(s7_valid),  .rgb_in     (s7_out),
        .rgb_out    (s8_out),    .pvalid_out (s8_valid)
    );

    // Force perfectly black pixels outside the window
    // in_window is already in sync with fb_data since drawX_d/drawY_d are passed in
    logic [11:0] in_window_pipe;
    always_ff @(posedge pixel_clk) begin
        if (reset)
            in_window_pipe <= 12'b0;
        else
            in_window_pipe <= {in_window_pipe[10:0], in_window};
    end
    assign filtered_rgb = in_window_pipe[11] ? s8_out : 24'h000000;
    assign pvalid_out   = s8_valid;

endmodule