
module ov7670_capture (
    input  logic        cam_pclk,
    input  logic        cam_vsync,
    input  logic        cam_href,
    input  logic [7:0]  cam_data,

    output logic [16:0] wr_addr,
    output logic [15:0] wr_data,
    output logic        wr_en
);

    logic [15:0] high_byte;
    logic        byte_sel;
    logic [9:0]  col;
    logic [9:0]  row;
    logic        vsync_prev;
    logic href_prev; // 1. Track the previous HREF state

    always_ff @(negedge cam_pclk) begin
        vsync_prev <= cam_vsync;
        href_prev  <= cam_href;  // 2. Assign it here
        wr_en      <= 1'b0;

        // 1. Detect New Frame
        if (vsync_prev && !cam_vsync) begin
            col      <= 10'd0;
            row      <= 10'd0;
            byte_sel <= 1'b0;

        // 2. Detect Horizontal Blanking (End of a line)
        end else if (!cam_href) begin
            byte_sel <= 1'b0;
            col <= 10'd0;
            
            // 3. Increment row ONLY on the falling edge of HREF
            if (href_prev && (row < 10'd479)) begin
                row <= row + 1;
            end

        // 3. Process Active Data
        end else if (cam_href) begin
            if (!byte_sel) begin
                high_byte <= cam_data;
                byte_sel  <= 1'b1;
            end else begin
                // If colors are still slightly off after fixing COM15, 
                // flip the high_byte and cam_data order here!
                wr_data  <= {cam_data[7:0], high_byte[7:0]};
                if ((col[0] == 1'b0) && (row[0] == 1'b0)) begin
                    // Math: (row / 2) * 320 + (col / 2)
                    wr_addr <= ({8'b0, row[9:1]} << 8) + ({8'b0, row[9:1]} << 6) + {7'b0, col[9:1]};
                    wr_en   <= 1'b1;
                end
                byte_sel <= 1'b0;
                // 4. Update coordinates (Row logic removed from here)
                if (col < 10'd639) begin
                    col <= col + 1;
                end
            end
        end
    end

endmodule